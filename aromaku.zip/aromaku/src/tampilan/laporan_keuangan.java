/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tampilan;
import javax.swing.*;                            // Komponen GUI seperti JFrame, JButton, JTextField, dsb.
import javax.swing.table.DefaultTableModel;     // Untuk model tabel (JTable)
import java.sql.Connection;                     // Untuk koneksi database
import java.sql.PreparedStatement;              // Untuk query SQL dengan parameter (INSERT, UPDATE, DELETE)
import java.sql.ResultSet;                      // Untuk membaca hasil SELECT
import java.sql.Statement;                      // Jika kamu pakai query biasa (tanpa parameter)
import koneksi.koneksi;
import java.awt.print.PrinterException;
import java.text.MessageFormat;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;


/**
 *
 * @author gungg
 */
public class laporan_keuangan extends javax.swing.JFrame {
DefaultTableModel model;
    /**
     * Creates new form laporan_keuangan
     */
    public laporan_keuangan() {
      initComponents();
        model = (DefaultTableModel) tabel_keuangan.getModel();
        tampilkanData(); 
        hitungTotal();
       
    }

private void tampilkanData() {
    model.setRowCount(0); // reset isi tabel
    try {
        Connection conn = new koneksi().connect();
        Statement stm = conn.createStatement();
        ResultSet rs = stm.executeQuery("SELECT * FROM laporan_keuangan");

        while (rs.next()) {
            Object[] row = {
                rs.getInt("no"),
                rs.getString("tanggal"),
                rs.getString("kategori"),
                rs.getString("keterangan"),
                rs.getDouble("pemasukan"),
                rs.getDouble("pengeluaran")
            };
            model.addRow(row);
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Gagal menampilkan data: " + e.getMessage());
    }
    }

private void hitungTotal() {
    double totalPemasukan = 0.0;
    double totalPengeluaran = 0.0;

    for (int i = 0; i < tabel_keuangan.getRowCount(); i++) {
        Object pemasukan = tabel_keuangan.getValueAt(i, 4);
        Object pengeluaran = tabel_keuangan.getValueAt(i, 5);

        if (pemasukan != null && !pemasukan.toString().isEmpty()) {
            totalPemasukan += Double.parseDouble(pemasukan.toString());
        }
        if (pengeluaran != null && !pengeluaran.toString().isEmpty()) {
            totalPengeluaran += Double.parseDouble(pengeluaran.toString());
        }
    }

    double saldo = totalPemasukan - totalPengeluaran;

    // Tampilkan ke field
    total_pemasukan.setText("Rp " + String.format("%,.2f", totalPemasukan));
    total_pengeluaran.setText("Rp " + String.format("%,.2f", totalPengeluaran));
    total_keluarmasuk.setText("Rp " + String.format("%,.2f", saldo));
}

public class TambahTransaksiDialog extends JDialog {
    private JTextField textTanggal, textKategori, textKeterangan, textPemasukan, textPengeluaran;
    
    public TambahTransaksiDialog(Frame parent, boolean modal) {
        super(parent, modal);
        setTitle("Tambah Transaksi");
        setSize(400, 300);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(6, 2));

        add(new JLabel("Tanggal (yyyy-MM-dd):"));
        textTanggal = new JTextField();
        add(textTanggal);

        add(new JLabel("Kategori:"));
        textKategori = new JTextField();
        add(textKategori);

        add(new JLabel("Keterangan:"));
        textKeterangan = new JTextField();
        add(textKeterangan);

        add(new JLabel("Pemasukan:"));
        textPemasukan = new JTextField("0");
        add(textPemasukan);

        add(new JLabel("Pengeluaran:"));
        textPengeluaran = new JTextField("0");
        add(textPengeluaran);

        JButton simpanButton = new JButton("Simpan");
        add(simpanButton);
        JButton batalButton = new JButton("Batal");
        add(batalButton);

        simpanButton.addActionListener(e -> simpanTransaksi());
        batalButton.addActionListener(e -> dispose());
    }

    private void simpanTransaksi() {
        try {
            String tanggal = textTanggal.getText().trim();
            String kategori = textKategori.getText().trim();
            String keterangan = textKeterangan.getText().trim();
            double pemasukan = Double.parseDouble(textPemasukan.getText().trim());
            double pengeluaran = Double.parseDouble(textPengeluaran.getText().trim());

            Connection conn = new koneksi().connect();
            String sql = "INSERT INTO laporan_keuangan (tanggal, kategori, keterangan, pemasukan, pengeluaran) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, tanggal);
            pst.setString(2, kategori);
            pst.setString(3, keterangan);
            pst.setDouble(4, pemasukan);
            pst.setDouble(5, pengeluaran);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Transaksi berhasil disimpan.");
            dispose(); // Tutup dialog

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan transaksi: " + ex.getMessage());
        }
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        cetak_pdf = new javax.swing.JButton();
        print = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        tabel_keuangan = new javax.swing.JTable();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        total_pemasukan = new javax.swing.JTextField();
        total_pengeluaran = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        total_keluarmasuk = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel36 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        tgl_awal = new javax.swing.JTextField();
        tgl_akhir = new javax.swing.JTextField();
        tampilkan = new javax.swing.JButton();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        kategori = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        cetak_pdf.setBackground(new java.awt.Color(51, 153, 0));
        cetak_pdf.setForeground(new java.awt.Color(255, 255, 255));
        cetak_pdf.setText("Cetak PDF");
        cetak_pdf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cetak_pdfActionPerformed(evt);
            }
        });

        print.setBackground(new java.awt.Color(0, 102, 153));
        print.setForeground(new java.awt.Color(255, 255, 255));
        print.setText("Print");
        print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printActionPerformed(evt);
            }
        });

        tabel_keuangan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "NO", "TANGGAL", "KATEGORI", "KETERANGAN", "PEMASUKAN", "PENGELUARAN"
            }
        ));
        jScrollPane4.setViewportView(tabel_keuangan);

        total_pemasukan.setText("Rp");
        total_pemasukan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                total_pemasukanActionPerformed(evt);
            }
        });

        total_pengeluaran.setText("Rp");
        total_pengeluaran.setToolTipText("");
        total_pengeluaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                total_pengeluaranActionPerformed(evt);
            }
        });

        jLabel34.setText("TOTAL");

        jLabel35.setText("SALDO");

        total_keluarmasuk.setText("Rp...................");
        total_keluarmasuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                total_keluarmasukActionPerformed(evt);
            }
        });

        jButton9.setBackground(new java.awt.Color(102, 204, 255));
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("+ Tambah Transaksi");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton1.setText("kembali");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(cetak_pdf, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(print)
                                .addGap(418, 418, 418)
                                .addComponent(jButton9))
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 757, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel34)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(total_pemasukan, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(total_pengeluaran, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel35)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(total_keluarmasuk, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel26))
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel28)
                                    .addComponent(jLabel31)
                                    .addComponent(jLabel32)))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jButton1)))
                .addContainerGap(101, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cetak_pdf, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(print, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 74, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton9)))
                .addGap(0, 0, 0)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(total_pemasukan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(total_pengeluaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(total_keluarmasuk))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel34)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel35)))
                .addGap(18, 18, 18)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(257, 257, 257)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel28)))
                .addContainerGap(56, Short.MAX_VALUE))
        );

        jLabel36.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel36.setText("LAPORAN");

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel37.setFont(new java.awt.Font("Segoe UI Emoji", 0, 16)); // NOI18N
        jLabel37.setText("Filter Laporan");

        jLabel38.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel38.setText("Mulai Tanggal");

        tgl_awal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tgl_awalActionPerformed(evt);
            }
        });

        tgl_akhir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tgl_akhirActionPerformed(evt);
            }
        });

        tampilkan.setBackground(new java.awt.Color(51, 204, 255));
        tampilkan.setForeground(new java.awt.Color(255, 255, 255));
        tampilkan.setText("Tampilkan");
        tampilkan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tampilkanActionPerformed(evt);
            }
        });

        jLabel39.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel39.setText("Sampai Tanggal");

        jLabel40.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel40.setText("Kategori");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel37)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tgl_awal, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel38))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tgl_akhir, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel39))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(kategori, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(tampilkan, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel40))))
                .addContainerGap(78, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel37)
                .addGap(16, 16, 16)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel38)
                    .addComponent(jLabel39)
                    .addComponent(jLabel40))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tgl_akhir, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(kategori, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tgl_awal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tampilkan)))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(66, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel36)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(280, Short.MAX_VALUE)))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(182, 182, 182)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(184, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel36)
                    .addGap(18, 18, 18)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(618, Short.MAX_VALUE)))
        );

        jScrollPane3.setViewportView(jPanel4);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 790, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(83, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 721, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 732, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 788, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1266, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cetak_pdfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cetak_pdfActionPerformed
        // TODO add your handling code here:
      try {
        MessageFormat header = new MessageFormat("Laporan Keuangan Toko Kue");
        MessageFormat footer = new MessageFormat("Halaman {0}");

        boolean complete = tabel_keuangan.print(JTable.PrintMode.FIT_WIDTH, header, footer);

        if (complete) {
            JOptionPane.showMessageDialog(this, "Cetak berhasil.");
        } else {
            JOptionPane.showMessageDialog(this, "Cetak dibatalkan.");
        }
    } catch (PrinterException ex) {
        JOptionPane.showMessageDialog(this, "Gagal mencetak: " + ex.getMessage());
    }
    
    }//GEN-LAST:event_cetak_pdfActionPerformed

    private void printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printActionPerformed
        // TODO add your handling code here:
        try {
        boolean complete = tabel_keuangan.print(JTable.PrintMode.FIT_WIDTH, 
            new MessageFormat("Laporan Keuangan"), 
            new MessageFormat("Halaman {0}"));

        if (complete) {
            JOptionPane.showMessageDialog(this, "Data berhasil dicetak!");
        } else {
            JOptionPane.showMessageDialog(this, "Pencetakan dibatalkan.");
        }
    } catch (PrinterException e) {
        JOptionPane.showMessageDialog(this, "Gagal mencetak: " + e.getMessage());
    }
    }//GEN-LAST:event_printActionPerformed

    private void total_pemasukanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_total_pemasukanActionPerformed
        // TODO add your handling code here:
           double totalPemasukan = 0.0;
    for (int i = 0; i < tabel_keuangan.getRowCount(); i++) {
        Object value = tabel_keuangan.getValueAt(i, 4); // kolom pemasukan
        if (value != null && !value.toString().isEmpty()) {
            totalPemasukan += Double.parseDouble(value.toString());
        }
    }
    JOptionPane.showMessageDialog(this, "Total Pemasukan: Rp " + totalPemasukan);
    }//GEN-LAST:event_total_pemasukanActionPerformed

    private void total_pengeluaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_total_pengeluaranActionPerformed
        // TODO add your handling code here:
         double totalPengeluaran = 0.0;
    for (int i = 0; i < tabel_keuangan.getRowCount(); i++) {
        Object value = tabel_keuangan.getValueAt(i, 5); // kolom pengeluaran
        if (value != null && !value.toString().isEmpty()) {
            totalPengeluaran += Double.parseDouble(value.toString());
        }
    }
    JOptionPane.showMessageDialog(this, "Total Pengeluaran: Rp " + totalPengeluaran);

    }//GEN-LAST:event_total_pengeluaranActionPerformed

    private void tgl_awalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tgl_awalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tgl_awalActionPerformed

    private void tgl_akhirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tgl_akhirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tgl_akhirActionPerformed

    private void tampilkanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tampilkanActionPerformed
        // TODO add your handling code here:
         String tglAwal = tgl_awal.getText().trim();     // format: yyyy-MM-dd
    String tglAkhir = tgl_akhir.getText().trim();   // format: yyyy-MM-dd
    String kategoriDipilih = kategori.getText().trim();

    model.setRowCount(0); // kosongkan tabel

    String sql = "SELECT * FROM laporan_keuangan WHERE tanggal BETWEEN ? AND ?";
boolean filterKategori = !(kategoriDipilih.isEmpty() || kategoriDipilih.equalsIgnoreCase("Semua"));
if (filterKategori) {
    sql += " AND kategori = ?";
}

    try {
        Connection conn = new koneksi().connect();
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tglAwal);
        pst.setString(2, tglAkhir);
        if (!kategoriDipilih.equalsIgnoreCase("Semua")) {
            pst.setString(3, kategoriDipilih);
        }

        ResultSet rs = pst.executeQuery();
        while (rs.next()) {
            Object[] row = {
                rs.getInt("no"),
                rs.getString("tanggal"),
                rs.getString("kategori"),
                rs.getString("keterangan"),
                rs.getDouble("pemasukan"),
                rs.getDouble("pengeluaran")
            };
            model.addRow(row);
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Gagal filter data: " + e.getMessage());
    }
     hitungTotal();
    }//GEN-LAST:event_tampilkanActionPerformed

    private void total_keluarmasukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_total_keluarmasukActionPerformed
        // TODO add your handling code here:
 double totalPemasukan = 0.0;
    double totalPengeluaran = 0.0;

    for (int i = 0; i < tabel_keuangan.getRowCount(); i++) {
        Object masuk = tabel_keuangan.getValueAt(i, 4);
        Object keluar = tabel_keuangan.getValueAt(i, 5);

        if (masuk != null && !masuk.toString().isEmpty()) {
            totalPemasukan += Double.parseDouble(masuk.toString());
        }
        if (keluar != null && !keluar.toString().isEmpty()) {
            totalPengeluaran += Double.parseDouble(keluar.toString());
        }
    }

    double selisih = totalPemasukan - totalPengeluaran;
    String hasil = (selisih >= 0) ? "Laba" : "Rugi";
    JOptionPane.showMessageDialog(this, hasil + ": Rp " + Math.abs(selisih));

    }//GEN-LAST:event_total_keluarmasukActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
    TambahTransaksiDialog dialog = new TambahTransaksiDialog(this, true);
    dialog.setVisible(true);
    tampilkanData(); // Refresh tabel setelah tambah
    hitungTotal();   // Refresh total
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         new dashboard().setVisible(true);
    dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(laporan_keuangan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(laporan_keuangan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(laporan_keuangan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(laporan_keuangan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new laporan_keuangan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cetak_pdf;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField kategori;
    private javax.swing.JButton print;
    private javax.swing.JTable tabel_keuangan;
    private javax.swing.JButton tampilkan;
    private javax.swing.JTextField tgl_akhir;
    private javax.swing.JTextField tgl_awal;
    private javax.swing.JButton total_keluarmasuk;
    private javax.swing.JTextField total_pemasukan;
    private javax.swing.JTextField total_pengeluaran;
    // End of variables declaration//GEN-END:variables
}
