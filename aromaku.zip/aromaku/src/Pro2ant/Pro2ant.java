/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pro2ant;
import koneksi.koneksi;
/**
 *
 * @author Lenovo
 */
public class Pro2ant {
    public static void main(String[] args){
        koneksi db = new koneksi();
        db.connect();
    }
}
